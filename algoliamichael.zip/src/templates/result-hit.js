import { addAbsolutePosition } from "instantsearch.js/es/lib/utils";

const resultHit = (hit,bindEvent) => `<div><a>
  <div class="result-hit__image-container">
    <img class="result-hit__image" src="${hit.image}" />
  </div>
  <div class="result-hit__details">
    <h3 class="result-hit__name">${hit._highlightResult.name.value}</h3>
    <p class="result-hit__price">$${hit.price}</p>
  </div>
  </a>
  <div class="result-hit__controls">
    <button id="view-item" class="result-hit__view" type="button" ${bindEvent('click', hit, 'Product Clicked')} >View</button>
    <button id="add-to-cart" class="result-hit__cart" type="button" ${bindEvent('conversion', hit, 'Product Added to Cart')} >Add To Cart</button>
  </div>
</div>`;


// function resH(hit, bindEvent){
//   return ``
// }
//    <button id="view-item" class="result-hit__view" onclick="product_click(${hit.objectID}, '${hit.__queryID}')">View</button>
//    <button id="add-to-cart" class="result-hit__cart" onclick="product_add_to_cart(${hit.objectID}, '${hit.__queryID}')">Add To Cart</button>


export default resultHit;

/*window.product_click = function(objectID, queryID){
  aa('clickedObjectIDs', {
    index: "products",
    eventName: "Product Clicked",
    objectIDs: [objectID.toString()]
  });
  console.log(objectID);
  console.log(queryID);
}*/

window.product_click = function(objectID, queryID){
  aa('clickedObjectIDsAfterSearch', {
    index: "products",
    eventName: "Product Clicked",
    objectIDs: [objectID.toString()],
    queryID: queryID.toString(),
    positions: [1]
  });
  console.log(objectID);
  console.log(queryID);
}

window.product_add_to_cart = function(objectID, queryID){
  aa('convertedObjectIDs', {
    index: "products",
    eventName: "Product Added to Cart",
    objectIDs: [objectID.toString()]
  });
  console.log(objectID);
  console.log(queryID);
}
