import algoliasearch from 'algoliasearch';
import instantsearch from 'instantsearch.js';
import { searchBox, hits, pagination, refinementList, configure } from 'instantsearch.js/es/widgets'; //added 'configure'
import { createInsightsMiddleware } from 'instantsearch.js/es/middlewares'; //added


import resultHit from '../templates/result-hit';

/**
 * @class ResultsPage
 * @description Instant Search class to display content on main page
 */
class ResultPage {
  constructor() {
    this._registerClient();
    this._registerWidgets();
    this._registerInsights(); //added
    this._startSearch();
  }

  /**
   * @private
   * Handles creating the search client and creating an instance of instant search
   * @return {void}
   */
  _registerClient() {
    this._searchClient = algoliasearch(
      process.env.ALGOLIA_APP_ID,
      process.env.ALGOLIA_API_KEY
    );

    this._searchInstance = instantsearch({
      indexName: process.env.ALGOLIA_INDEX,
      searchClient: this._searchClient,
    });
  }

  /**
   * @private
   * Adds widgets to the Algolia instant search instance
   * @return {void}
   */
  _registerWidgets() {
    this._searchInstance.addWidgets([
      searchBox({
        container: '#searchbox',
      }),
      hits({
        container: '#hits',
        templates: { //templates is an object with property 'item'. resultHit is a function defined in the result-hit.js file.
          item: resultHit
        },
      }),
      pagination({
        container: '#pagination',
      }),
      refinementList({
        container: '#brand-facet',
        attribute: 'brand',
      }),
      refinementList({
        container: '#categories-facet',
        attribute: 'categories',
      }),  
      configure({ //added
        clickAnalytics: true,
      }),   
    ]);
  }

  _registerInsights() {
    this._insightsMiddleware = createInsightsMiddleware({
      insightsClient: window.aa,
    });

    this._searchInstance.use(this._insightsMiddleware);

    const userToken = "test_user"

    // The `insights` middleware receives a notification
    // and attaches the `userToken` to search calls onwards.
    window.aa('setUserToken', userToken);
  }



  /**
   * @private
   * Starts instant search after widgets are registered
   * @return {void}
   */
  _startSearch() {
    this._searchInstance.start();
  }
}

export default ResultPage;
