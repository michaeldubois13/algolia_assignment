// README - this solution uses the API Client, so to run use: $node question_1.js
// README - I have exceeded my record quota of 10,000. This script will throw an error (403) unless the existing records are deleted from Algolia first.

// Install the API client: https://www.algolia.com/doc/api-client/getting-started/install/javascript/?client=javascript
const algoliasearch = require("algoliasearch");
const dotenv = require("dotenv");

dotenv.config();

// Get your Algolia Application ID and (admin) API key from the dashboard: https://www.algolia.com/account/api-keys
// and choose a name for your index. Add these environment variables to a `.env` file:
const ALGOLIA_APP_ID = process.env.ALGOLIA_APP_ID;
const ALGOLIA_API_KEY = process.env.ALGOLIA_API_KEY;
const ALGOLIA_INDEX = process.env.ALGOLIA_INDEX;

// Start the API client
// https://www.algolia.com/doc/api-client/getting-started/instantiate-client-index/
const client = algoliasearch(ALGOLIA_APP_ID, ALGOLIA_API_KEY);

// Create an index (or connect to it, if an index with the name `ALGOLIA_INDEX_NAME` already exists)
// https://www.algolia.com/doc/api-client/getting-started/instantiate-client-index/#initialize-an-index
const index = client.initIndex(ALGOLIA_INDEX);

//Loading in products.json
var products = require('./data/products.json');

//Reducing prices by 20% and rounding to lowest full number.
products.forEach(function(product){
    //determine if product is in the camera category
    var is_camera = false;
    product.categories.forEach(function(category){
        if(category.includes("Camera" || "camera")){
            is_camera = true;
        }
    });
    //if product is in the Camera category, reduce price
    if(is_camera){
        product.price = Math.floor(product.price * .8);
    }
});

// Add new object array to the index
// https://www.algolia.com/doc/api-reference/api-methods/add-objects/
index.saveObjects(products);
